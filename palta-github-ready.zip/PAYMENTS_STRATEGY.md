# Payments — Build Now, Integrate Later

Your decision is right and the codebase already supports it:
**get the technology working end-to-end now; plug in each real payment
provider later, per country, with no code rewrite.**

Here's exactly how that works and what to do when you're ready.

---

## How it works today (no real payment accounts needed)

The payment layer is built as **swappable adapters** behind one interface
(`PaymentAdapter`: `collect / payout / verify / handleWebhook`).

- **No credentials set → mock mode.** Every adapter (M-Pesa, Stripe, EVC)
  detects missing keys and returns a **simulated** success/pending. The whole
  order → pay → track flow works so you can build and demo everything.
- **Country with no integration yet → cash-on-delivery.** The registry falls
  back to a `CashOnlyAdapter`, so the app still functions and clearly shows
  limited payment methods instead of breaking.
- **`LAUNCHED` set** marks which markets are truly live (currently just `KE`).

So right now you can:
- Place orders, dispatch drivers, track deliveries, pay drivers — all end to
  end — with **zero payment accounts**. Money movement is mocked.

## What "integrate a payment later" actually takes

When you have the real merchant account for a market, it's a **config change,
not a rewrite**:

### M-Pesa (Kenya) — `adapters/mpesa.ke.js`
1. Get M-Pesa **Daraja** credentials from Safaricom (consumer key/secret,
   shortcode, passkey, callback URL).
2. Set them as env vars on your host (Render dashboard, never in git):
   ```
   MPESA_CONSUMER_KEY=...
   MPESA_CONSUMER_SECRET=...
   MPESA_SHORTCODE=...
   MPESA_PASSKEY=...
   MPESA_CALLBACK_URL=https://your-backend/…/mpesa/callback
   ```
3. The adapter auto-detects the keys and switches from mock → **real STK push**.
   The real Daraja calls are already written (as comments) in the adapter next
   to the mock path — enable them. No other file changes.

### Cards (Stripe) — `adapters/card.stripe.js`
Same pattern: set `STRIPE_SECRET_KEY`, it goes live.

### Other markets
Add a market = **one adapter file + one line in the registry** + its env keys.
Templates for MTN MoMo, Telebirr, Razorpay are noted in `registry.js`.

## The golden rule (already enforced in the code)
**Never store card numbers or mobile-money PINs.** Adapters hand raw payment
data to the provider and keep only a token/reference. Keep it that way for PCI
/ data-protection compliance.

---

## So the plan is clean:

| Phase | Payments |
|-------|----------|
| **Now — build the tech** | Mock mode / cash-on-delivery. Everything works. |
| **Per market, when ready** | Get provider account → set env keys → real payments live, no rewrite. |
| **Kenya first** | M-Pesa Daraja is the one to integrate first (your launch market). |

You are architected correctly for this. Focus on finishing the technology
(the app features + backend integration); payments will slot in when you have
the Safaricom/Stripe accounts — a deploy-time config step, not a code project.
