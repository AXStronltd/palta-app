// Restaurant owner routes — the third side of the marketplace.
// A RESTAURANT-role user manages exactly one restaurant (via ownerId).
// This replaces the admin/dev shortcuts for accepting + readying orders.

const express = require("express");
const { z } = require("zod");
const { prisma } = require("../prisma");
const { requireAuth } = require("../middleware/auth");
const { transition } = require("../services/order");
const { offerToNext } = require("../services/dispatch");
const { emitToUser } = require("../realtime");

const router = express.Router();
router.use(requireAuth);

// Resolve the restaurant this user owns. RESTAURANT role required.
async function getOwnedRestaurant(req, res) {
  if (req.user.role !== "RESTAURANT") {
    res.status(403).json({ error: "Restaurant access required" });
    return null;
  }
  const restaurant = await prisma.restaurant.findFirst({
    where: { ownerId: req.user.userId },
  });
  if (!restaurant) {
    res.status(404).json({ error: "No restaurant linked to this account" });
    return null;
  }
  return restaurant;
}

// GET /restaurant/me — the owner's restaurant + menu.
// If the owner hasn't created a storefront yet, returns needsSetup:true
// (so the dashboard can show the self-service create form).
router.get("/me", async (req, res) => {
  if (req.user.role !== "RESTAURANT") {
    return res.status(403).json({ error: "Restaurant access required" });
  }
  const restaurant = await prisma.restaurant.findFirst({ where: { ownerId: req.user.userId } });
  if (!restaurant) {
    return res.json({ needsSetup: true, restaurant: null, menuItems: [] });
  }
  const menuItems = await prisma.menuItem.findMany({ where: { restaurantId: restaurant.id } });
  res.json({ needsSetup: false, restaurant, menuItems });
});

// GET /restaurant/orders — orders for this restaurant, newest first
router.get("/orders", async (req, res) => {
  const restaurant = await getOwnedRestaurant(req, res);
  if (!restaurant) return;
  const orders = await prisma.order.findMany({
    where: { restaurantId: restaurant.id },
    include: { customer: { select: { name: true } }, driver: { select: { name: true } } },
    orderBy: { createdAt: "desc" },
    take: 100,
  });
  res.json({ orders });
});

// POST /restaurant/orders/:id/accept — PLACED -> ACCEPTED
router.post("/orders/:id/accept", async (req, res) => {
  const restaurant = await getOwnedRestaurant(req, res);
  if (!restaurant) return;
  const order = await prisma.order.findUnique({ where: { id: req.params.id } });
  if (!order || order.restaurantId !== restaurant.id) {
    return res.status(404).json({ error: "Order not found" });
  }
  try {
    const updated = await transition(order.id, "ACCEPTED");
    emitToUser(order.customerId, "order:update", { orderId: order.id, status: "ACCEPTED" });
    res.json({ order: updated });
  } catch (err) {
    if (err.code === "ILLEGAL_TRANSITION") return res.status(409).json({ error: "Order can't be accepted now" });
    throw err;
  }
});

// POST /restaurant/orders/:id/reject — PLACED -> REJECTED
router.post("/orders/:id/reject", async (req, res) => {
  const restaurant = await getOwnedRestaurant(req, res);
  if (!restaurant) return;
  const order = await prisma.order.findUnique({ where: { id: req.params.id } });
  if (!order || order.restaurantId !== restaurant.id) {
    return res.status(404).json({ error: "Order not found" });
  }
  try {
    const updated = await transition(order.id, "REJECTED");
    emitToUser(order.customerId, "order:update", { orderId: order.id, status: "REJECTED" });
    res.json({ order: updated });
  } catch (err) {
    if (err.code === "ILLEGAL_TRANSITION") return res.status(409).json({ error: "Order can't be rejected now" });
    throw err;
  }
});

// POST /restaurant/orders/:id/preparing — ACCEPTED -> PREPARING
router.post("/orders/:id/preparing", async (req, res) => {
  const restaurant = await getOwnedRestaurant(req, res);
  if (!restaurant) return;
  const order = await prisma.order.findUnique({ where: { id: req.params.id } });
  if (!order || order.restaurantId !== restaurant.id) {
    return res.status(404).json({ error: "Order not found" });
  }
  try {
    const updated = await transition(order.id, "PREPARING");
    emitToUser(order.customerId, "order:update", { orderId: order.id, status: "PREPARING" });
    res.json({ order: updated });
  } catch (err) {
    if (err.code === "ILLEGAL_TRANSITION") return res.status(409).json({ error: "Can't start preparing now" });
    throw err;
  }
});

// POST /restaurant/orders/:id/ready — PREPARING -> READY (triggers dispatch)
router.post("/orders/:id/ready", async (req, res) => {
  const restaurant = await getOwnedRestaurant(req, res);
  if (!restaurant) return;
  const order = await prisma.order.findUnique({ where: { id: req.params.id } });
  if (!order || order.restaurantId !== restaurant.id) {
    return res.status(404).json({ error: "Order not found" });
  }
  try {
    const updated = await transition(order.id, "READY");
    emitToUser(order.customerId, "order:update", { orderId: order.id, status: "READY" });
    const offered = await offerToNext(order.id); // find a driver
    res.json({ order: updated, dispatch: offered ? "offered" : "no-drivers" });
  } catch (err) {
    if (err.code === "ILLEGAL_TRANSITION") return res.status(409).json({ error: "Order isn't ready to mark ready" });
    throw err;
  }
});

// POST /restaurant/open — toggle open/closed
const openSchema = z.object({ isOpen: z.boolean() });
router.post("/open", async (req, res) => {
  const restaurant = await getOwnedRestaurant(req, res);
  if (!restaurant) return;
  const parsed = openSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "isOpen required" });
  const updated = await prisma.restaurant.update({
    where: { id: restaurant.id },
    data: { isOpen: parsed.data.isOpen },
  });
  res.json({ isOpen: updated.isOpen });
});

// --- Menu management ---
const menuItemSchema = z.object({
  name: z.string().min(1).max(80),
  description: z.string().max(300).optional(),
  price: z.number().min(0).max(10000),
  category: z.string().min(1).max(40),
  isAvailable: z.boolean().optional(),
});

// POST /restaurant/menu — add an item
router.post("/menu", async (req, res) => {
  const restaurant = await getOwnedRestaurant(req, res);
  if (!restaurant) return;
  const parsed = menuItemSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Invalid item" });
  const item = await prisma.menuItem.create({
    data: {
      restaurantId: restaurant.id,
      name: parsed.data.name,
      description: parsed.data.description || null,
      price: parsed.data.price,
      category: parsed.data.category,
      isAvailable: parsed.data.isAvailable ?? true,
    },
  });
  res.status(201).json({ item });
});

// PATCH /restaurant/menu/:id — edit an item (incl. availability)
router.patch("/menu/:id", async (req, res) => {
  const restaurant = await getOwnedRestaurant(req, res);
  if (!restaurant) return;
  const item = await prisma.menuItem.findUnique({ where: { id: req.params.id } });
  if (!item || item.restaurantId !== restaurant.id) {
    return res.status(404).json({ error: "Item not found" });
  }
  const parsed = menuItemSchema.partial().safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Invalid update" });
  const updated = await prisma.menuItem.update({ where: { id: item.id }, data: parsed.data });
  res.json({ item: updated });
});

// DELETE /restaurant/menu/:id
router.delete("/menu/:id", async (req, res) => {
  const restaurant = await getOwnedRestaurant(req, res);
  if (!restaurant) return;
  const item = await prisma.menuItem.findUnique({ where: { id: req.params.id } });
  if (!item || item.restaurantId !== restaurant.id) {
    return res.status(404).json({ error: "Item not found" });
  }
  await prisma.menuItem.delete({ where: { id: item.id } });
  res.json({ deleted: true });
});

// POST /restaurant/signup — a RESTAURANT-role user creates their own
// storefront (self-service onboarding). One storefront per owner.
const signupSchema = z.object({
  name: z.string().min(1).max(80),
  merchantType: z.enum(["RESTAURANT", "GROCERY", "PHARMACY", "RETAIL", "CONVENIENCE"]).optional(),
  cuisineType: z.string().min(1).max(40),   // for shops: a category label e.g. "Grocery"
  address: z.string().min(1).max(200),
  lat: z.number(),
  lng: z.number(),
  description: z.string().max(300).optional(),
  deliveryFee: z.number().min(0).max(100).optional(),
  estimatedPrepTime: z.number().int().min(1).max(240).optional(),
});

router.post("/signup", async (req, res) => {
  if (req.user.role !== "RESTAURANT") {
    return res.status(403).json({ error: "Sign in as a merchant account first" });
  }
  const existing = await prisma.restaurant.findFirst({ where: { ownerId: req.user.userId } });
  if (existing) {
    return res.status(409).json({ error: "This account already has a storefront", restaurant: existing });
  }
  const parsed = signupSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Missing or invalid storefront details" });

  const restaurant = await prisma.restaurant.create({
    data: {
      ownerId: req.user.userId,
      merchantType: parsed.data.merchantType || "RESTAURANT",
      name: parsed.data.name,
      cuisineType: parsed.data.cuisineType,
      address: parsed.data.address,
      lat: parsed.data.lat,
      lng: parsed.data.lng,
      description: parsed.data.description || null,
      deliveryFee: parsed.data.deliveryFee ?? 0,
      estimatedPrepTime: parsed.data.estimatedPrepTime ?? 20,
      isOpen: true,
    },
  });
  res.status(201).json({ restaurant });
});

module.exports = router;
