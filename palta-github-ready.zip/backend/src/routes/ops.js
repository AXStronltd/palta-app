// Ops/dev routes — advance an order through its lifecycle.
//
// Until the restaurant app exists (later), these let you (or an admin
// tool) move an order ACCEPTED -> PREPARING -> READY, which triggers
// dispatch to offer the order to drivers.
//
// In production these actions belong to the restaurant + admin dashboards
// (Day 13). Guarded by auth; tighten to admin-only there.

const express = require("express");
const { z } = require("zod");
const { prisma } = require("../prisma");
const { requireAuth } = require("../middleware/auth");
const { transition } = require("../services/order");
const { offerToNext } = require("../services/dispatch");
const { emitToUser } = require("../realtime");

const router = express.Router();
router.use(requireAuth);

const advanceSchema = z.object({
  orderId: z.string().min(1),
  to: z.enum(["ACCEPTED", "PREPARING", "READY", "REJECTED"]),
});

// POST /ops/advance  { orderId, to }
router.post("/advance", async (req, res) => {
  const parsed = advanceSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "orderId and valid 'to' required" });

  try {
    const order = await transition(parsed.data.orderId, parsed.data.to);

    // Notify the customer of the status change.
    emitToUser(order.customerId, "order:update", {
      orderId: order.id,
      status: order.status,
    });

    // When it hits READY, kick off dispatch.
    if (order.status === "READY") {
      const offered = await offerToNext(order.id);
      return res.json({ order, dispatch: offered ? "offered" : "no-drivers" });
    }

    res.json({ order });
  } catch (err) {
    if (err.code === "ILLEGAL_TRANSITION") {
      return res.status(409).json({ error: err.message });
    }
    console.error("[/ops/advance]", err.message);
    res.status(500).json({ error: "Could not advance order" });
  }
});

module.exports = router;
