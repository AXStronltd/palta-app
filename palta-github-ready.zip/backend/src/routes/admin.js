// Admin routes — the real ops surface. Replaces the dev shortcuts.
// All require the ADMIN role.

const express = require("express");
const { z } = require("zod");
const { prisma } = require("../prisma");
const { requireAdmin } = require("../middleware/auth");
const { emitToUser } = require("../realtime");

const router = express.Router();
router.use(requireAdmin);

// GET /admin/stats — dashboard summary
router.get("/stats", async (_req, res) => {
  const [customers, drivers, pendingKyc, ordersToday, activeOrders] = await Promise.all([
    prisma.user.count({ where: { role: "CUSTOMER" } }),
    prisma.driverProfile.count({ where: { kycStatus: "APPROVED" } }),
    prisma.driverProfile.count({ where: { kycStatus: "PENDING", kycSubmittedAt: { not: null } } }),
    prisma.order.count({ where: { createdAt: { gte: startOfDay() } } }),
    prisma.order.count({ where: { status: { in: ["PLACED", "ACCEPTED", "PREPARING", "READY", "DRIVER_ASSIGNED", "PICKED_UP", "DELIVERING"] } } }),
  ]);
  res.json({ customers, approvedDrivers: drivers, pendingKyc, ordersToday, activeOrders });
});

function startOfDay() {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  return d;
}

// GET /admin/drivers?status=PENDING — drivers by KYC status
router.get("/drivers", async (req, res) => {
  const status = req.query.status;
  const where = status ? { kycStatus: status } : {};
  const drivers = await prisma.driverProfile.findMany({
    where: status === "PENDING" ? { ...where, kycSubmittedAt: { not: null } } : where,
    include: { user: { select: { name: true, phone: true } }, documents: true },
    orderBy: { kycSubmittedAt: "desc" },
  });
  res.json({ drivers });
});

const reviewSchema = z.object({
  decision: z.enum(["APPROVED", "REJECTED"]),
  note: z.string().max(300).optional(),
});

// POST /admin/drivers/:userId/review — approve or reject KYC
router.post("/drivers/:userId/review", async (req, res) => {
  const parsed = reviewSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "decision required" });

  const profile = await prisma.driverProfile.findUnique({ where: { userId: req.params.userId } });
  if (!profile) return res.status(404).json({ error: "Driver not found" });

  const updated = await prisma.driverProfile.update({
    where: { userId: req.params.userId },
    data: { kycStatus: parsed.data.decision, kycReviewNote: parsed.data.note || null },
  });

  // Notify the driver in realtime + (Day 13) push.
  emitToUser(req.params.userId, "kyc:update", {
    kycStatus: parsed.data.decision,
    note: parsed.data.note || null,
  });

  res.json({ profile: updated });
});

// GET /admin/orders?status= — orders, newest first
router.get("/orders", async (req, res) => {
  const status = req.query.status;
  const orders = await prisma.order.findMany({
    where: status ? { status } : {},
    include: {
      restaurant: { select: { name: true } },
      customer: { select: { name: true, phone: true } },
      driver: { select: { name: true } },
    },
    orderBy: { createdAt: "desc" },
    take: 100,
  });
  res.json({ orders });
});

// POST /admin/orders/:id/status — force a status (ops override)
const statusSchema = z.object({
  status: z.enum(["ACCEPTED", "PREPARING", "READY", "REJECTED", "CANCELLED"]),
});
router.post("/orders/:id/status", async (req, res) => {
  const parsed = statusSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Invalid status" });

  const { transition } = require("../services/order");
  const { offerToNext } = require("../services/dispatch");

  try {
    const order = await transition(req.params.id, parsed.data.status);
    emitToUser(order.customerId, "order:update", { orderId: order.id, status: order.status });
    if (order.status === "READY") {
      await offerToNext(order.id);
    }
    res.json({ order });
  } catch (err) {
    if (err.code === "ILLEGAL_TRANSITION") return res.status(409).json({ error: err.message });
    throw err;
  }
});

module.exports = router;
