// Push notifications via Expo's push service.
//
// Apps register their Expo push token (from expo-notifications). We store
// it on the user and send notifications through Expo's HTTP endpoint —
// no native Firebase/APNs setup needed for development.
//
// To move off Expo later (bare workflow / FCM / APNs directly), swap the
// send() implementation; call sites stay the same.

const { prisma } = require("../prisma");

const EXPO_PUSH_URL = "https://exp.host/--/api/v2/push/send";

async function sendToUser(userId, { title, body, data }) {
  const user = await prisma.user.findUnique({ where: { id: userId } });
  if (!user?.pushToken) return; // no token registered yet

  const message = {
    to: user.pushToken,
    sound: "default",
    title,
    body,
    data: data || {},
  };

  try {
    await fetch(EXPO_PUSH_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(message),
    });
  } catch (err) {
    console.error("[push] send failed:", err.message);
  }
}

module.exports = { sendToUser };
