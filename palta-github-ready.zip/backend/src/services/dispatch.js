// ============================================================
// Dispatch — the logistics brain (rule-based v1).
// ============================================================
//
// When an order is READY, dispatch finds the best available driver and
// sends them a request. They accept or decline; on decline (or timeout)
// we offer the next driver.
//
// Day 8 = rule-based: nearest online, approved, free driver wins.
// The AI/ML "predictive dispatch" (pre-positioning before food is ready)
// upgrades this later once real order data exists — same interface, so
// nothing else changes. This is the honest "heuristic now, ML later" step.
// ============================================================

const { prisma } = require("../prisma");
const { emitToUser } = require("../realtime");

// Haversine distance in km.
function distanceKm(lat1, lng1, lat2, lng2) {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLng = ((lng2 - lng1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

// In-memory record of pending offers so we don't double-offer.
// Map orderId -> { driverIds: Set, offeredTo: string, expiresAt }
const pendingOffers = new Map();

const OFFER_TTL_MS = 30 * 1000; // 30s to accept

/**
 * Find candidate drivers for an order, nearest first.
 * A candidate is: role DRIVER, kyc APPROVED, online, not already on an
 * active delivery, and (optionally) excluding ids that already declined.
 */
async function findCandidates(order, exclude = new Set()) {
  // Resolve the PICKUP point for this job. Food/shop orders pick up from the
  // merchant; parcels carry their own pickup coordinates. Dispatch keys off
  // pickup, never off "restaurant" — so every job type dispatches identically.
  let pickupLat = order.pickupLat;
  let pickupLng = order.pickupLng;
  let restaurant = null;
  if ((pickupLat == null || pickupLng == null) && order.restaurantId) {
    restaurant = await prisma.restaurant.findUnique({
      where: { id: order.restaurantId },
    });
    if (restaurant) {
      pickupLat = restaurant.lat;
      pickupLng = restaurant.lng;
    }
  }

  const profiles = await prisma.driverProfile.findMany({
    where: { kycStatus: "APPROVED", isOnline: true },
    include: { user: true },
  });

  // Drivers currently on an active order are busy.
  const activeStatuses = ["DRIVER_ASSIGNED", "PICKED_UP", "DELIVERING"];
  const busy = await prisma.order.findMany({
    where: { status: { in: activeStatuses }, driverId: { not: null } },
    select: { driverId: true },
  });
  const busyIds = new Set(busy.map((b) => b.driverId));

  const candidates = profiles
    .filter((p) => !busyIds.has(p.userId) && !exclude.has(p.userId))
    .map((p) => ({
      userId: p.userId,
      name: p.user?.name || p.fullName || "Driver",
      distanceKm:
        p.currentLat != null && pickupLat != null
          ? distanceKm(p.currentLat, p.currentLng, pickupLat, pickupLng)
          : 9999,
    }))
    .sort((a, b) => a.distanceKm - b.distanceKm);

  return { candidates, restaurant, pickupLat, pickupLng };
}

/**
 * Offer an order to the next best driver. Emits "delivery:request" to them.
 * Returns the driver offered, or null if none available.
 */
async function offerToNext(orderId, declinedBy = new Set()) {
  const order = await prisma.order.findUnique({
    where: { id: orderId },
    include: { restaurant: { select: { name: true, address: true, lat: true, lng: true } } },
  });
  if (!order || order.status !== "READY") return null;

  const { candidates } = await findCandidates(order, declinedBy);
  if (candidates.length === 0) {
    pendingOffers.delete(orderId);
    return null;
  }

  const chosen = candidates[0];
  pendingOffers.set(orderId, {
    offeredTo: chosen.userId,
    declinedBy,
    expiresAt: Date.now() + OFFER_TTL_MS,
  });

  emitToUser(chosen.userId, "delivery:request", {
    orderId: order.id,
    restaurant: order.restaurant,
    deliveryAddress: order.deliveryAddress,
    total: order.total,
    itemCount: Array.isArray(order.items) ? order.items.length : 0,
    distanceKm: Number(chosen.distanceKm.toFixed(1)),
    expiresInMs: OFFER_TTL_MS,
  });

  // Off-screen push so drivers don't miss offers.
  const { sendToUser } = require("./push");
  sendToUser(chosen.userId, {
    title: "New delivery request",
    body: `${order.restaurant?.name || "A restaurant"} · ${chosen.distanceKm.toFixed(1)} km away`,
    data: { type: "delivery_request", orderId: order.id },
  });

  // Auto-expire and move on if not accepted.
  setTimeout(() => {
    const offer = pendingOffers.get(orderId);
    if (offer && offer.offeredTo === chosen.userId && Date.now() >= offer.expiresAt) {
      const nextDeclined = new Set(declinedBy);
      nextDeclined.add(chosen.userId);
      offerToNext(orderId, nextDeclined);
    }
  }, OFFER_TTL_MS + 500);

  return chosen;
}

/**
 * A driver accepts. Validates they were the one offered, assigns them,
 * and transitions READY -> DRIVER_ASSIGNED. Returns the updated order.
 */
async function acceptOffer(orderId, driverId) {
  const offer = pendingOffers.get(orderId);
  if (!offer || offer.offeredTo !== driverId) {
    const err = new Error("This delivery is no longer available");
    err.code = "OFFER_GONE";
    throw err;
  }
  const order = await prisma.order.findUnique({ where: { id: orderId } });
  if (!order || order.status !== "READY") {
    pendingOffers.delete(orderId);
    const err = new Error("This delivery is no longer available");
    err.code = "OFFER_GONE";
    throw err;
  }

  const updated = await prisma.order.update({
    where: { id: orderId },
    data: { status: "DRIVER_ASSIGNED", driverId },
  });
  pendingOffers.delete(orderId);

  // Tell the customer a driver is on the way.
  emitToUser(order.customerId, "order:update", {
    orderId,
    status: "DRIVER_ASSIGNED",
    driverId,
  });

  const { sendToUser } = require("./push");
  sendToUser(order.customerId, {
    title: "Your driver is on the way",
    body: "A driver has been assigned to your order.",
    data: { type: "order_update", orderId, status: "DRIVER_ASSIGNED" },
  });

  return updated;
}

/**
 * A driver declines. Offer the next candidate.
 */
async function declineOffer(orderId, driverId) {
  const offer = pendingOffers.get(orderId);
  const declined = new Set(offer?.declinedBy || []);
  declined.add(driverId);
  return offerToNext(orderId, declined);
}

module.exports = { offerToNext, acceptOffer, declineOffer, findCandidates, distanceKm, pendingOffers };
