// Structured logger — JSON lines in production (parseable by log tooling),
// readable text in dev. Levels: debug < info < warn < error, gated by
// LOG_LEVEL (default "info"). Attaches request id + method + path when a
// request context is passed.

const LEVELS = { debug: 10, info: 20, warn: 30, error: 40 };
const THRESHOLD = LEVELS[process.env.LOG_LEVEL] || LEVELS.info;
const AS_JSON = process.env.NODE_ENV === "production";
const SILENT = process.env.NODE_ENV === "test";

function emit(level, msg, meta) {
  if (SILENT) return;
  if (LEVELS[level] < THRESHOLD) return;
  const rec = { time: new Date().toISOString(), level, msg, ...(meta || {}) };
  if (AS_JSON) {
    console[level === "debug" ? "log" : level](JSON.stringify(rec));
  } else {
    const tag = meta?.reqId ? ` [${meta.reqId}]` : "";
    const extra = meta ? Object.entries(meta).filter(([k]) => k !== "reqId").map(([k, v]) => `${k}=${v}`).join(" ") : "";
    console[level === "debug" ? "log" : level](`${rec.time} ${level.toUpperCase()}${tag} ${msg}${extra ? " " + extra : ""}`);
  }
}

const logger = {
  debug: (msg, meta) => emit("debug", msg, meta),
  info: (msg, meta) => emit("info", msg, meta),
  warn: (msg, meta) => emit("warn", msg, meta),
  error: (msg, meta) => emit("error", msg, meta),
};

module.exports = { logger };
