// Order service — creates orders and guards the status state machine.
// Every status change goes through transition(), which refuses illegal
// jumps. This is the backend half of the state machine defined in
// packages/shared (PLACED -> ACCEPTED -> ... -> DELIVERED).

const { prisma } = require("../prisma");
const { ORDER_TRANSITIONS, canTransition } = require("./orderStateMachine");

/**
 * Recompute totals server-side from the DB — never trust client prices.
 * Takes the cart lines the client sent, looks up each menu item, and
 * rebuilds price/subtotal from authoritative data.
 */
async function priceOrder({ restaurantId, lines, tip = 0 }) {
  const restaurant = await prisma.restaurant.findUnique({ where: { id: restaurantId } });
  if (!restaurant) throw new Error("Restaurant not found");

  const menuItems = await prisma.menuItem.findMany({ where: { restaurantId } });
  const byId = new Map(menuItems.map((m) => [m.id, m]));

  const items = [];
  let subtotal = 0;

  for (const line of lines) {
    const item = byId.get(line.menuItemId);
    if (!item || !item.isAvailable) continue; // drop anything not real/available

    // Options priced from what the client sent but validated against the
    // item's real option groups.
    const validOptions = validateOptions(item, line.options || []);
    const optionsTotal = validOptions.reduce((s, o) => s + (o.price || 0), 0);
    const quantity = Math.max(1, Math.min(20, parseInt(line.quantity, 10) || 1));
    const unitPrice = item.price + optionsTotal;

    items.push({
      menuItemId: item.id,
      name: item.name,
      price: unitPrice,
      quantity,
      options: validOptions,
      notes: (line.notes || "").slice(0, 200),
    });
    subtotal += unitPrice * quantity;
  }

  if (items.length === 0) throw new Error("Cart is empty or has no valid items");

  subtotal = Number(subtotal.toFixed(2));
  const deliveryFee = restaurant.deliveryFee || 0;
  const safeTip = Math.max(0, Number(tip) || 0);
  const total = Number((subtotal + deliveryFee + safeTip).toFixed(2));

  return { restaurant, items, subtotal, deliveryFee, tip: safeTip, total };
}

// Only keep options that actually exist in the item's option groups,
// and take their price from the menu, not the client.
function validateOptions(item, clientOptions) {
  const groups = item.options?.groups || [];
  const realChoices = new Map();
  for (const g of groups) {
    for (const c of g.choices || []) realChoices.set(c.id, c);
  }
  const out = [];
  for (const o of clientOptions) {
    const real = realChoices.get(o.id);
    if (real) out.push({ id: real.id, name: real.name, price: real.price || 0 });
  }
  return out;
}

async function createOrder({ customerId, restaurantId, lines, tip, deliveryAddress, deliveryType, currency, country }) {
  const priced = await priceOrder({ restaurantId, lines, tip });

  const order = await prisma.order.create({
    data: {
      customerId,
      restaurantId,
      currency: currency || "AED",
      country: country || "AE",
      status: "PLACED",
      items: priced.items,
      subtotal: priced.subtotal,
      deliveryFee: priced.deliveryFee,
      tip: priced.tip,
      total: priced.total,
      deliveryAddress: deliveryAddress || "",
      deliveryType: deliveryType || "DELIVERY",
    },
  });

  return order;
}

async function transition(orderId, to) {
  const order = await prisma.order.findUnique({ where: { id: orderId } });
  if (!order) throw new Error("Order not found");
  if (!canTransition(order.status, to)) {
    const err = new Error(`Illegal transition ${order.status} -> ${to}`);
    err.code = "ILLEGAL_TRANSITION";
    throw err;
  }
  const updated = await prisma.order.update({
    where: { id: orderId },
    data: {
      status: to,
      ...(to === "PICKED_UP" ? { pickedUpAt: new Date() } : {}),
      ...(to === "DELIVERED" ? { deliveredAt: new Date() } : {}),
    },
  });

  // ---- Card 13: push the status change live to everyone watching this order ----
  // The customer's tracking screen and the driver's job screen subscribe to
  // `order:status` for this order and update instantly — no polling, no timers.
  try {
    const { emitToUser } = require("../realtime");
    const payload = {
      orderId: updated.id,
      status: updated.status,
      jobType: updated.jobType,
      at: new Date().toISOString(),
    };
    if (updated.customerId) emitToUser(updated.customerId, "order:status", payload);
    if (updated.driverId) emitToUser(updated.driverId, "order:status", payload);
    // notify the merchant too (their order board)
    if (updated.restaurantId) {
      const r = await prisma.restaurant.findUnique({
        where: { id: updated.restaurantId },
        select: { ownerId: true },
      });
      if (r?.ownerId) emitToUser(r.ownerId, "order:status", payload);
    }
  } catch (e) {
    // realtime is best-effort; the status change itself already succeeded.
  }

  return updated;
}

module.exports = { createOrder, transition, canTransition, priceOrder, ORDER_TRANSITIONS };
