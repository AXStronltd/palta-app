// ============================================================
// Key-value store — Redis in production, in-memory in dev.
// ============================================================
// One interface, two backends. If REDIS_URL is set, uses Redis (survives
// restarts, shared across server instances). Otherwise an in-memory Map
// with TTL support, so everything works locally with zero setup.
//
// Used for: OTP codes, dispatch offers, rate-limit counters — all the
// ephemeral state that must NOT live in a single process's memory in
// production (it'd be lost on restart and wouldn't scale horizontally).
// ============================================================

const REDIS_URL = process.env.REDIS_URL || "";

// --- In-memory backend (dev / fallback) ---
function makeMemoryStore() {
  const map = new Map(); // key -> { value, expiresAt|null }

  function alive(entry) {
    if (!entry) return false;
    if (entry.expiresAt && Date.now() > entry.expiresAt) return false;
    return true;
  }

  return {
    backend: "memory",
    async get(key) {
      const e = map.get(key);
      if (!alive(e)) { map.delete(key); return null; }
      return e.value;
    },
    async set(key, value, ttlSeconds) {
      map.set(key, { value, expiresAt: ttlSeconds ? Date.now() + ttlSeconds * 1000 : null });
    },
    async del(key) { map.delete(key); },
    // Atomic increment with optional TTL on first set — used by rate limiter.
    async incr(key, ttlSeconds) {
      const e = map.get(key);
      let n;
      if (!alive(e)) { n = 1; map.set(key, { value: 1, expiresAt: ttlSeconds ? Date.now() + ttlSeconds * 1000 : null }); }
      else { n = Number(e.value) + 1; e.value = n; }
      return n;
    },
    async ttl(key) {
      const e = map.get(key);
      if (!alive(e) || !e.expiresAt) return -1;
      return Math.ceil((e.expiresAt - Date.now()) / 1000);
    },
    async quit() { map.clear(); },
  };
}

// --- Redis backend (production) ---
function makeRedisStore(url) {
  const Redis = require("ioredis");
  const client = new Redis(url);
  client.on("error", (e) => console.error("[redis]", e.message));

  return {
    backend: "redis",
    client,
    async get(key) { return client.get(key); },
    async set(key, value, ttlSeconds) {
      if (ttlSeconds) await client.set(key, String(value), "EX", ttlSeconds);
      else await client.set(key, String(value));
    },
    async del(key) { await client.del(key); },
    async incr(key, ttlSeconds) {
      const n = await client.incr(key);
      if (n === 1 && ttlSeconds) await client.expire(key, ttlSeconds);
      return n;
    },
    async ttl(key) { return client.ttl(key); },
    async quit() { await client.quit(); },
  };
}

let store;
function getStore() {
  if (store) return store;
  store = REDIS_URL ? makeRedisStore(REDIS_URL) : makeMemoryStore();
  if (process.env.NODE_ENV !== "test") {
    console.log(`[kv] using ${store.backend} backend`);
  }
  return store;
}

module.exports = { getStore, makeMemoryStore };
