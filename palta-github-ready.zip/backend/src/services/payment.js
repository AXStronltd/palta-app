// ============================================================
// Payment provider — the ONE file to change when you pick a country.
// ============================================================
//
// The rest of the app calls createPaymentIntent() and never touches
// Stripe (or any provider) directly. To switch to Paymob, Razorpay,
// PayTabs, Checkout.com, etc., implement the same two functions and
// swap the export at the bottom.
//
// Modes:
//   - "cash"   : cash on delivery — no gateway call, always succeeds
//   - "card"   : creates a real payment intent with the provider
//
// DEV: if STRIPE_SECRET_KEY is unset, card payments run in a MOCK mode
// so you can build the whole flow without a Stripe account yet.
// ============================================================

const STRIPE_SECRET = process.env.STRIPE_SECRET_KEY || "";

// --- Stripe implementation ---
const stripeProvider = {
  name: "stripe",

  async createPaymentIntent({ amount, currency, orderId }) {
    // amount is in major units (e.g. dollars); Stripe wants minor (cents).
    const minor = Math.round(amount * 100);

    if (!STRIPE_SECRET) {
      // MOCK mode — no key set. Lets the full flow work in dev.
      return {
        provider: "stripe-mock",
        clientSecret: `mock_secret_${orderId}`,
        paymentIntentId: `pi_mock_${orderId}`,
        mock: true,
      };
    }

    // Real Stripe call (only runs when a key is present).
    const Stripe = require("stripe");
    const stripe = new Stripe(STRIPE_SECRET);
    const intent = await stripe.paymentIntents.create({
      amount: minor,
      currency: currency.toLowerCase(),
      metadata: { orderId },
      automatic_payment_methods: { enabled: true },
    });
    return {
      provider: "stripe",
      clientSecret: intent.client_secret,
      paymentIntentId: intent.id,
      mock: false,
    };
  },

  // Confirm is normally done client-side with the clientSecret. This is a
  // server-side check used after the fact / for mock mode.
  async verifyPayment(paymentIntentId) {
    if (!STRIPE_SECRET || paymentIntentId.startsWith("pi_mock_")) {
      return { status: "succeeded", mock: true };
    }
    const Stripe = require("stripe");
    const stripe = new Stripe(STRIPE_SECRET);
    const intent = await stripe.paymentIntents.retrieve(paymentIntentId);
    return { status: intent.status, mock: false };
  },
};

// The active provider. Swap this line to change gateways.
const provider = stripeProvider;

module.exports = { provider };
