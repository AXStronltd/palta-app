// Pure order state machine — no dependencies (no Prisma), so it's unit
// testable in isolation. order.js re-exports these.

const ORDER_TRANSITIONS = {
  PLACED: ["ACCEPTED", "REJECTED", "CANCELLED"],
  ACCEPTED: ["PREPARING", "CANCELLED"],
  PREPARING: ["READY", "CANCELLED"],
  READY: ["DRIVER_ASSIGNED", "CANCELLED"],
  DRIVER_ASSIGNED: ["PICKED_UP", "CANCELLED"],
  PICKED_UP: ["DELIVERING", "CANCELLED"],
  DELIVERING: ["DELIVERED", "CANCELLED"],
  DELIVERED: [],
  CANCELLED: [],
  REJECTED: [],
};

function canTransition(from, to) {
  return (ORDER_TRANSITIONS[from] || []).includes(to);
}

module.exports = { ORDER_TRANSITIONS, canTransition };
