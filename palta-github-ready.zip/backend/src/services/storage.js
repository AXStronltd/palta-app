// File storage — the ONE file to change to move uploads to S3/R2/GCS.
//
// Dev: writes to backend/uploads/ and serves them at /uploads/<name>.
// Prod: implement the same saveBuffer() returning a public URL.

const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const UPLOAD_DIR = path.join(__dirname, "..", "..", "uploads");

// Ensure the dir exists in dev.
try {
  fs.mkdirSync(UPLOAD_DIR, { recursive: true });
} catch {}

const storage = {
  // buffer: Buffer, ext: e.g. "jpg". Returns a public-ish URL path.
  async saveBuffer(buffer, ext = "jpg") {
    const name = `${crypto.randomBytes(12).toString("hex")}.${ext}`;
    const dest = path.join(UPLOAD_DIR, name);
    await fs.promises.writeFile(dest, buffer);
    return `/uploads/${name}`;
  },
};

module.exports = { storage, UPLOAD_DIR };
