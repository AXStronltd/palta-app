# Palta — Your Next Steps (What YOU Do, In Order)

The code is built. These are the steps only you can do, sequenced so each
one unblocks the next. Nothing here is code — it's accounts, clicks, and
real-world action.

Time estimates assume you're doing it yourself. A developer would be faster.

---

## STEP 1 — Get the code on GitHub  (~10 min)
Follow `DEPLOY_TO_GITHUB.md` (Part 1). Push the repo to a private GitHub repo.
✅ Result: your code is versioned and ready to deploy.

## STEP 2 — Deploy the backend live  (~10 min)
Follow `DEPLOY_TO_GITHUB.md` (Part 2). Render Blueprint reads `render.yaml`,
creates the API + PostgreSQL + Redis, runs the migration, gives you a URL.
✅ Result: a live backend at `https://palta-backend.onrender.com`.
✅ This is the BIGGEST unlock — now everything can be tested for real.

## STEP 3 — Point the apps at the live backend  (~5 min)
In `apps/customer/app.json` and `apps/driver/app.json`, set
`extra.apiUrl` to your Render URL. (Already scaffolded — just paste the URL.)
✅ Result: the apps talk to the live backend, not localhost.

## STEP 4 — Run the apps and test the real loop  (~30 min)
```
cd apps/customer && npm install && npx expo start
cd apps/driver   && npm install && npx expo start
```
Scan the QR with Expo Go on your phone. Test: sign up → browse → order →
(as driver) get the alarm → accept → deliver → watch the customer's tracking
update live. Everything is mocked payments / cash, so it all works.
✅ Result: you've seen the whole platform work end-to-end, live.

## STEP 5 — Seed some demo data  (~5 min)
From Render's shell (or locally against the live DB):
`npm run seed --workspace=backend`
✅ Result: real restaurants/products to browse instead of an empty app.

---
## When you're ready to go to REAL money & launch:

## STEP 6 — M-Pesa (Kenya)  (days — Safaricom approval)
Apply for M-Pesa Daraja (Safaricom developer portal). Get consumer key/secret,
shortcode, passkey. Set them as env vars in Render (see `PAYMENTS_STRATEGY.md`).
The adapter switches from mock → real automatically. No code change.
✅ Result: real payments in Kenya.

## STEP 7 — SMS for OTP  (~1 hour)
Open an Africa's Talking account. Set its keys in Render.
✅ Result: real SMS login codes instead of the dev code.

## STEP 8 — KYC + data protection  (legal — plan ahead)
Pick a KYC/ID provider; ensure encrypted ID storage per Kenya's Data
Protection Act. This is a legal requirement before onboarding real drivers.
✅ Result: you can legally verify and onboard drivers.

## STEP 9 — Security pass before public  (~1 day, ideally a developer)
Confirm: JWT secret from env, HTTPS only, helmet on, rate limits, no secrets
in git, encryption at rest. Much is already done — audit before launch.

## STEP 10 — Build the apps for the stores  (~half day)
```
npm i -g eas-cli
eas build --platform all   # in each app
```
Apple Developer ($99/yr) + Google Play ($25 one-time) accounts required.
Submit with `eas submit`.
✅ Result: Palta is downloadable from the App Store / Play Store.

---
## THE REAL LAUNCH (not code — this is the actual business)

## STEP 11 — Pick ONE launch zone
Not "Kenya." One neighborhood — e.g. Westlands + Kilimani. Density beats
coverage. Uber won by owning small areas first.

## STEP 12 — Recruit drivers in that zone
This is the make-or-break. You need enough drivers that a rider gets a car
in under 5 minutes in your zone. No app succeeds without this. Sign up,
verify (KYC), and incentivize the first cohort.

## STEP 13 — Onboard shops/restaurants in that same zone
A cluster of merchants in the launch zone so there's real supply to order
from. The web dashboard is ready for them.

## STEP 14 — Soft launch to real users in the zone
Friends, family, the neighborhood. Watch what breaks. Fix. Then widen.

---

## Honest priorities
1. **Deploy (Steps 1–5).** Do this first. It makes everything real and
   testable. ~40 minutes of your time.
2. **Drivers (Step 12) is the hardest problem** and the one no code solves.
   Start thinking about it now, in parallel.
3. Payments/KYC/stores (6–10) come when you're ready to handle real money
   and real users — the code already supports plugging them in.

You have a genuinely well-built platform. The gap to launch is now accounts,
deployment, and — above all — people (drivers and shops). That's business
work, not more building.
