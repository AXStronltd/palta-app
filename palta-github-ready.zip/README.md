# Palta 2030 — AI-Native Food Delivery

Monorepo for the Palta platform.

## Structure

```
palta/
├── apps/
│   ├── customer/   # React Native (Expo) — customer app (chat-first + browse)
│   └── driver/     # React Native (Expo) — driver app
├── backend/        # Node.js + Express + Prisma + AI layer
└── packages/
    └── shared/     # Shared types & constants
```

## Day 1 — what runs

- Backend `GET /health` → `{ status: "ok" }`
- Backend `POST /ai/ping` → real LLM reply

## Day 2 — what runs

- **Auth:** `POST /auth/request-otp` → `POST /auth/verify` → JWT
  (OTP is faked in dev — the code is returned in the response and logged)
- **Restaurants:** `GET /restaurants`, `GET /restaurants/:id`
- **Conversational ordering:** `POST /ai/order` (auth required) — turns a
  natural-language message into a verified cart of real menu items
- **Customer app:** phone login → restaurant list → AI ordering chat →
  review order. The AI builds your cart from live menu prices.

### The grounding guarantee
The AI can only ever choose real, in-stock items. Enforced twice: in the
prompt (only given real items) and in code (`verifyCart` drops anything
hallucinated or unavailable and takes prices from the database). Tested.

## Day 3 — what runs

- **Addresses:** `GET/POST/PATCH/DELETE /addresses` (auth required) — a
  customer's saved delivery locations
- **Geocoding (Mapbox proxy):** `GET /geo/search`, `GET /geo/reverse`,
  `GET /geo/config` — token stays server-side; swap providers in one file
- **Customer app:** the home screen now leads with a **delivery address
  bar**. Tap it → search an address (live Mapbox geocoding) → see a static
  map preview → label it Home/Work/Other → save. The chosen address is
  remembered across launches and shown at checkout. You can't order until
  an address is set.

> Note: Day 3 uses Mapbox **static map images** for previews (works in
> Expo Go). The interactive map SDK arrives Day 11 for live tracking,
> which needs a custom dev build anyway.

### Set MAPBOX_TOKEN
Add `MAPBOX_TOKEN` to `backend/.env` (get a free token at mapbox.com).
Without it, geocoding returns a clear error and previews show a fallback.

## Day 4 — what runs

- **Browse/search/filter:** `GET /restaurants` now takes `q` (matches
  restaurant name, cuisine, AND dish names), `cuisine`, `minRating`,
  `maxPrepTime`, `maxDeliveryFee`, and `sort` (rating / prepTime /
  deliveryFee). Plus `GET /restaurants/cuisines` for the filter chips.
- **Seed:** 8 restaurants across 8 cuisines, each with a full menu.
- **Customer app home screen:** search bar (searches dishes too), a row
  of cuisine chips, a filter sheet (sort, min rating, max delivery time),
  and live results that update as you type or tap. Empty state included.

> Run `npm run seed` again after pulling Day 4 to load the expanded data.

## Day 5 — what runs

- **Restaurant page:** tap a restaurant → menu grouped by category, with a
  sticky cart bar and an "or tell Palta what you want" entry to the AI flow.
- **Item detail:** option groups (required single-select like "Cook", or
  optional multi like "Add-ons"), live price as you pick, quantity stepper,
  and special instructions. Required options are enforced.
- **One shared cart:** the flagship structural win. Items added by **tapping**
  and items built by **AI chat** write to the same cart store, so checkout
  shows a single order. Switching restaurants prompts a reset.
- **Checkout** now reads that shared cart with editable quantities.
- **Menu items** gained an `options` field (add-on groups); Nova Burgers is
  seeded with real options to demo it.

> Schema changed (MenuItem.options). Run `npx prisma migrate dev` and
> `npm run seed` after pulling Day 5.

## Day 6 — what runs

- **Place an order:** `POST /orders` creates the order, recomputes every
  price server-side (client prices are never trusted), and returns a
  payment intent. `GET /orders`, `GET /orders/:id`, `POST /orders/:id/cancel`.
- **Payments:** a provider abstraction (`services/payment.js`) wraps Stripe.
  Leave `STRIPE_SECRET_KEY` blank to run in **mock mode** — the whole flow
  works with no Stripe account. Cash-on-delivery supported too. **This is
  the one file to swap when you pick a country's gateway.**
- **State machine guard:** `services/order.js` enforces legal status
  transitions; illegal jumps (e.g. PREPARING→DELIVERED) are refused.
- **Customer app:** checkout now has delivery/pickup toggle, tip, payment
  method, live totals, and a real **Place order** button → confirmation
  screen → **My orders** list with live statuses.

### Security proven by tests
- A client sending `price: 0.01` is charged the real DB price. Fake options
  and sold-out items are dropped. (15 checks.)
- Illegal status transitions throw; re-cancelling a cancelled order → 409.

## Day 7 — what runs (Driver app comes alive)

> Note: Day 7 = driver registration + KYC (moved up, since payments landed
> early on Day 6).

- **Driver app** is now a real app: phone-OTP login (role=DRIVER) →
  **KYC onboarding** → pending review → approved home.
- **KYC flow:** personal details, vehicle info, and document uploads
  (license, national ID, vehicle photo) via the phone's image picker.
  Submit is blocked until required fields + all 3 docs are present.
- **Backend:** `GET /driver/me`, `PATCH /driver/profile`,
  `POST /driver/documents` (base64 upload), `POST /driver/submit`.
  Documents stored via a storage abstraction (local disk in dev, one file
  to swap for S3/R2). Uploads served at `/uploads/...`.
- **Dev shortcut:** set `AUTO_APPROVE_KYC=1` to auto-approve on submit and
  skip the admin step (admin approval UI comes Day 13).

> **On real ID verification:** this builds the full capture-and-submit
> pipeline. Actually *verifying* a license is genuine is a third-party,
> country-specific service (Onfido/Persona/regional) — wired at the
> marked HOOK in `routes/driver.js` once you pick a launch country.

> Schema changed (DriverProfile + DriverDocument). Run
> `npx prisma migrate dev` after pulling Day 7.

## Day 8 — what runs (Dispatch loop begins)

- **Realtime:** Socket.IO layer with per-user rooms. Clients authenticate
  the socket with their JWT; the server pushes targeted events.
- **Driver:** `POST /driver/online` (approved-only), `POST /driver/location`,
  `POST /driver/accept`, `POST /driver/decline`, `GET /driver/active`.
- **Dispatch** (`services/dispatch.js`) — the rule-based logistics brain:
  when an order hits READY it offers to the **nearest online approved free
  driver**, with a 30s countdown; on decline/timeout it offers the next.
  (This is the "heuristic now, ML later" step — predictive dispatch upgrades
  this behind the same interface once real data exists.)
- **Ops:** `POST /ops/advance` moves an order ACCEPTED→PREPARING→READY
  (stands in for the restaurant app until Day 13) and triggers dispatch.
- **Driver app:** online/offline toggle, live location streaming, and a
  **delivery-request modal** with a live countdown and accept/decline.
  Accepted orders show as the active delivery. Customer is notified in
  realtime when a driver is assigned.

### Proven by tests (10 checks)
Unapproved-can't-go-online, **nearest driver wins**, a non-offered driver
can't accept (409), accept → DRIVER_ASSIGNED + customer notified, active
order queryable.

## Day 9 — what runs (Delivery lifecycle)

- **Driver actions:** `POST /driver/order/:id/action` with `arrived`,
  `pickup`, `deliver`, or `complete`. Each validates driver ownership and
  goes through the state-machine guard (`DRIVER_ASSIGNED → PICKED_UP →
  DELIVERING → DELIVERED`). "arrived" is a flag/notification, not a status.
- **Earnings:** completing a delivery records an `Earning` (delivery fee +
  tip). `GET /driver/earnings` returns today/total/history.
- **Driver app:** active-delivery screen with a progress tracker, a
  destination card + "Open in Maps", an "I've arrived" step, and the
  primary action button that walks pickup → deliver → complete. Earnings
  show in the header. On completion the driver is freed for the next order.
- Customer is notified in realtime at every step (drives Day 11 tracking).

### Proven by tests (11 checks)
Illegal actions rejected (complete-before-deliver, act-on-delivered → 409),
non-owner blocked (404), arrival flag + notify, each step advances +
notifies, earnings = fee + tip, driver freed after delivery.

> Schema changed (Order fields + Earning model). Run
> `npx prisma migrate dev` after pulling Day 9.

## Day 10 — what runs (Customer live tracking)

- **Customer socket client** mirrors the driver's; authenticates with JWT.
- **Enriched order detail:** `GET /orders/:id` now includes the assigned
  driver's name + vehicle/plate + live coordinates once a driver is on it.
- **Tracking screen:** a live status timeline (placed → accepted →
  preparing → ready → driver assigned → picked up → on the way →
  delivered) that updates in **realtime** from the `order:update` events
  the driver side emits. Shows a driver card once assigned, "arrived at
  restaurant" state, cancel (while allowed), cancelled/rejected states, and
  an order summary.
- Reachable from the order-placed screen ("Track order") and the orders list.

### Proven by tests (8 checks)
Fresh order shows no driver, another customer gets 404, assigned order
surfaces driver name + vehicle + plate, arrival flag propagates, journey
has the correct 8 stages.

## Day 11 — what runs (Live map tracking)

- **LiveMap component** (both apps): renders driver + destination +
  restaurant on a Mapbox map. Default uses **static map images** so it
  runs in Expo Go and updates in realtime as the driver moves. A native
  `@rnmapbox/maps` upgrade (smooth animated marker) is documented in
  `apps/customer/src/components/LiveMap.native-notes.md` — same props,
  needs a custom dev build.
- **Customer tracking** now shows the live map during DRIVER_ASSIGNED →
  PICKED_UP → DELIVERING, consuming the `driver:location` socket events.
- **Driver active-delivery** shows a map of their position + current target.
- **Privacy:** the driver's location stops flowing to the customer the
  moment the delivery completes (tested).

### Proven by tests (11 checks)
Map URL builder: no-token/no-marker fallbacks, correct marker order,
Mapbox lng,lat convention, token embedding. Location flow: event reaches
the right customer with coords, and no location leak after delivery.

> No schema change on Day 11.

## Day 12 — what runs (Ratings, receipts, reorder)

- **Rate:** `POST /orders/:id/rate` — food + optional driver stars +
  comment, only on a delivered order, once. Updates the restaurant's
  rolling average automatically.
- **Receipt:** `GET /orders/:id/receipt` — structured breakdown (items,
  options, subtotal, delivery, tip, total, timestamps).
- **Reorder:** `GET /orders/:id/reorder` — rebuilds cart-ready lines from a
  past order, re-validated against the **current** menu (current prices,
  drops now-unavailable items and reports them).
- **Customer app:** delivered orders show Rate / Reorder / Receipt actions.
  Rating screen (food + driver stars + comment), receipt screen, and
  reorder that drops you into checkout with the cart pre-filled.

### Proven by tests (7 checks)
Can't-rate-before-delivered (409), rate works, restaurant average updates,
double-rate blocked (409), receipt well-formed, reorder returns lines at
current prices.

> Schema changed (Rating model). Run `npx prisma migrate dev` after Day 12.

## Day 13 — what runs (Notifications & Admin)

- **Admin role + guard:** new ADMIN role; `requireAdmin` middleware.
- **Admin API:** `/admin/stats`, `/admin/drivers?status=PENDING`,
  `/admin/drivers/:id/review` (approve/reject KYC), `/admin/orders`,
  `/admin/orders/:id/status` (ops override). Replaces the dev shortcuts.
- **Ops console** (`admin/index.html`): a single-file web dashboard — log in
  as an admin, see live stats, review pending drivers (with document
  thumbnails) and approve/reject, browse orders. No build step; open the
  file or serve the folder, and set the API URL if not localhost.
- **Push notifications** (`services/push.js`, via Expo): drivers get a push
  on a new delivery request; customers get one when a driver is assigned.
  Apps register their token via `POST /auth/push-token`.
- **Seed** now creates an admin user (`+9715550000`) for the console.

### Proven by tests (8 checks)
Non-admin blocked (403), no-token (401), stats, pending-driver list,
approve flips status + notifies driver, pending count updates, push-token
registration.

> Schema changed (ADMIN role + User.pushToken). Run `npx prisma migrate dev`.
> Log into the ops console with the seeded admin phone + its dev OTP.

## Day 14 — Testing & launch (complete)

- **Full-platform E2E test:** the entire flow in one run — customer +
  driver signup → driver KYC → admin approval → discovery → AI ordering →
  driver online → order placed (server-priced) → dispatch → accept →
  pickup → deliver → complete → earnings → rating → receipt → reorder →
  admin stats. 17/17 behaviors verified.
- **LAUNCH_CHECKLIST.md** — honest production-readiness status: what's ready,
  what's stubbed, the launch-country decisions, security hardening, and
  infrastructure to stand up.

**All 14 days complete.** Every file across both apps + backend + admin
parses; the full order loop is proven end to end.

See `LAUNCH_CHECKLIST.md` for exactly what to do before going live.

## Restaurant dashboard — the third side (complete)

Palta is now a **three-sided marketplace**: customer, driver, and restaurant.
The restaurant dashboard replaces the admin/dev shortcut for accepting and
readying orders — restaurants now drive their own orders.

- **Owner link:** `Restaurant.ownerId` ties a restaurant to a RESTAURANT-role
  user. The seed links Nova Burgers to owner `+9715551111`.
- **Restaurant API** (`routes/restaurant-owner.js`, all ownership-enforced):
  `GET /restaurant/me`, `GET /restaurant/orders`,
  `POST /restaurant/orders/:id/{accept,reject,preparing,ready}`
  (ready triggers driver dispatch), `POST /restaurant/open` (open/closed
  toggle), and menu CRUD (`POST/PATCH/DELETE /restaurant/menu`).
- **New orders** notify the owner in realtime (`order:new` socket event).
- **Dashboard** (`restaurant/index.html`): single-file web app — log in
  (role RESTAURANT), live order queue with accept/reject/preparing/ready,
  open/closed toggle, and menu management. New orders arrive live via
  Socket.IO with a title-bar alert. No build step.

**Run it:** open `restaurant/index.html` (or serve the `restaurant/` folder),
log in with the seeded owner phone `+9715551111` + its dev OTP.

### Proven by tests (12 checks)
Non-restaurant blocked (403), owner sees own restaurant, menu add/toggle/
delete, owner notified of new order, other owner can't touch it (404),
accept→ACCEPTED (+customer notified), ready→READY (+dispatch), illegal
re-accept (409), open toggle, reject→REJECTED.

### Bug caught & fixed
The auth verify schema only allowed CUSTOMER/DRIVER roles — RESTAURANT/ADMIN
users couldn't be created at all. Fixed (with a note that production should
restrict RESTAURANT/ADMIN to admin-granted, not self-selected).

> Schema changed (Restaurant.ownerId). Run `npx prisma migrate dev`.

## Day 16 + 17 — Shops (multi-merchant) + login check

Palta now serves **restaurants AND other shops** (grocery, pharmacy,
convenience, retail) — without changing anything that already worked. A shop
is the same as a restaurant under the hood, distinguished by `merchantType`
(defaults to RESTAURANT, so every existing merchant is unaffected).

**Day 16 — shops onboard themselves + customers order from both:**
- `MerchantType` enum + `Restaurant.merchantType` field.
- **Self-service signup:** `POST /restaurant/signup` — a merchant account
  creates its own storefront (name, type, category, address, coords, fee).
  One storefront per owner (duplicate → 409). `GET /restaurant/me` now
  returns `needsSetup:true` when a merchant hasn't created one yet.
- **Merchant dashboard** shows a storefront-setup form on first login, with a
  merchant-type picker; wording generalised to "for Merchants".
- **Customer app** gains merchant-type tabs (Food / Grocery / Pharmacy /
  Convenience / Retail) on top of the existing cuisine chips; `?type=`
  filter added to `GET /restaurants`.
- **Seed** adds a grocery (FreshMart) and pharmacy (CarePlus) so both kinds
  are browsable out of the box.

**Day 17 — login check across every role:**
Verified CUSTOMER, DRIVER, RESTAURANT (merchant), and ADMIN can all log in,
and that role separation still holds (a customer is still blocked from the
merchant area).

### Proven by tests (16 checks)
All four roles log in; new merchant needsSetup; self-signup creates a
storefront; duplicate blocked (409); shop adds products; browse shows both
shop + restaurant; type filters isolate each; customer orders from a shop
AND a restaurant; customer still blocked from merchant area (403).

> Schema changed (MerchantType + Restaurant.merchantType). Run
> `npx prisma migrate dev`. Existing rows default to RESTAURANT.

## Upgrade — Global reach with per-country customisation

Palta is no longer tied to one country. A **country configuration layer**
lets each country plug in its own payment gateway, SMS provider, KYC vendor,
currency, locale, and phone rules — while the core platform stays identical
everywhere. This is how global delivery platforms are actually built.

**The layer:**
- **Provider interfaces** (`providers/interfaces.js`) — contracts every
  vendor adapter must satisfy (PaymentProvider, SmsProvider, KycProvider).
  The core code only ever calls the interface, never a vendor SDK.
- **Adapters:** a real **Stripe** payment adapter and **Twilio** SMS adapter
  (both mock-capable for dev), plus interface-conforming **stubs** for
  regional vendors (Paymob, PayTabs, Razorpay, Unifonic, MSG91, Onfido) that
  throw a clear "not implemented" only if invoked before you wire them.
- **Country registry** (`config/countries.js`) — each country declares its
  currency, symbol, locale, timezone, distance unit, dial code, phone regex,
  KYC requirement, and which providers it uses. Ships with AE, US, GB, IN, EG.
  `ENABLED_COUNTRIES` / `DEFAULT_COUNTRY` env vars control what's live.
- **Resolver** (`config/resolver.js`) — "for country X, which provider?"
  Providers are built once per country and cached. Also does locale-aware
  money formatting and per-country phone validation.
- **Wired in:** orders are stamped with the merchant's `country` + `currency`
  and routed to that country's **payment provider automatically**. OTP goes
  through the country's SMS provider. Users store their country. New
  `GET /config/countries` powers an in-app country picker.

**Adding a country later** = one config entry + its three providers. No core
changes. You never have to pick "one country" — configure as many as you want.

### Proven by tests (31 checks)
Registry + resolver pick the right provider per country (Stripe for US,
PayTabs for AE, Razorpay for IN, Paymob for EG, Onfido KYC for GB); provider
caching; locale-aware currency formatting ($, ₹, AED); per-country phone
validation; Stripe mock intent + refund; regional stub loads but throws
clearly when used; and the live order flow stamps currency + routes payment
by merchant country.

> Schema changed (User.country, Restaurant.country/currency, Order.country/
> currency). Run `npx prisma migrate dev`. Existing rows default to AE/AED.

## Upgrade Week 2 — Redis, hardening, and a real test suite

Production-readiness pass on the backend foundation.

- **KV store** (`services/kv.js`) — one interface, two backends: **Redis**
  when `REDIS_URL` is set (survives restarts, shared across instances),
  in-memory otherwise. Supports get/set/del/incr/ttl.
- **OTP moved to the KV store** — codes now survive restarts and scale
  horizontally; TTL handles expiry; codes are one-time-use.
- **Rate limiting** (`middleware/rateLimit.js`, KV-backed so limits hold
  across instances): OTP requests capped per phone (5 / 10 min, stops
  SMS-bombing), verify attempts capped per IP (10 / 10 min, stops
  brute-force). Returns 429 + `Retry-After`.
- **Structured logging** (`services/logger.js`) — levelled, JSON in prod,
  readable in dev, silent in tests. **Request context** middleware assigns
  each request an id (`X-Request-Id`) and logs method/path/status/duration.
- **Centralized error handler + 404** — consistent `{ error }` envelope,
  no stack traces leaked to clients.
- **Health probes** — `/health` (liveness) and `/health/ready` (readiness:
  checks DB + KV, 503 if a dependency is down).
- **Pure state machine module** (`services/orderStateMachine.js`) — extracted
  so it's unit-testable without Prisma.

### Real Jest test suite (`npm test`)
Replaces the ad-hoc scripts with repeatable, CI-ready tests:
`tests/kv.test.js`, `tests/country.test.js`, `tests/order-state.test.js`,
`tests/rateLimit.test.js` — **31 unit tests**, plus a **9-check integration
pass** (health probes, request id, rate limiting, KV OTP one-time-use, 404
envelope). 40 green total.

> New dev deps: jest, supertest. New runtime dep: ioredis (only connects if
> `REDIS_URL` is set). No schema change this week.
>
> **Note:** Redis itself isn't in this sandbox, so the KV logic is tested
> against the in-memory backend; the Redis path activates and is verified
> when you run with a real `REDIS_URL`.

## Upgrade Week 3 — Docker, CI/CD, deployment

Palta is now shippable.

- **Dockerfile** (`backend/Dockerfile`) — multi-stage production image:
  build stage installs deps + `prisma generate`; lean `node:22-slim` runtime
  running as non-root with a built-in healthcheck. `.dockerignore` keeps it
  small.
- **docker-compose.yml** — the whole stack in one command: Postgres + Redis
  + API, with the API health-gated on its dependencies and running
  `prisma migrate deploy` before boot.
- **CI/CD** (`.github/workflows/ci.yml`) — on every push/PR: spins up real
  Postgres + Redis, installs, generates the Prisma client, migrates, runs
  `npm test`, then builds the Docker image (only if tests pass).
- **.env.example** expanded with every variable (Redis, Twilio, countries,
  log level). **.gitignore** hardened so secrets never land in git.
- **DEPLOYMENT.md** — local Docker, the image, CI/CD, cloud hosting
  (Fly/Render/Railway and K8s/ECS), and a deployment checklist.

### Validated
`npm test` (the exact CI step) passes — 31 tests. Dockerfile stages,
compose services, and CI job graph all structurally validated against the
real project files.

> **Honest limits:** Docker isn't available in this build sandbox, so the
> image build wasn't executed here — the Dockerfile/compose/CI are validated
> for correctness and the test step is proven, but the first real
> `docker compose up` happens on your machine. Also, no committed Prisma
> `migrations/` folder exists yet (needs DB access to generate) — see
> DEPLOYMENT.md for the one command to create it before first deploy.

## Upgrade Week 4 — Multi-currency in the apps + country picker

The global backend now reaches the UI. Prices display in the right currency
everywhere, driven by real data — no more hardcoded `$`.

- **Shared money formatter** (`lib/money.js` in customer + driver apps) —
  locale-aware, per-currency symbols (AED, USD, GBP, INR, EGP, EUR). One
  place; no screen hardcodes a currency.
- **Customer app:** currency wired through every price surface — restaurant
  list, menu, item detail, checkout, receipt, orders list, tracking,
  order-placed, and AI ordering. Currency follows the merchant.
- **Country picker at signup** — the login screen fetches enabled countries
  from `/config/countries` and lets the customer pick; country flows into
  OTP request + verify and is stored on the user.
- **Driver app:** earnings display in the driver's home-country currency
  (backend `/driver/earnings` now returns `currency`).
- **Merchant dashboard + admin console:** money formatted by the
  restaurant's / each order's currency (admin sees mixed-currency orders
  correctly).
- **Receipt endpoint** now returns `currency`.

### Proven by tests
Currency-flow integration (6 checks): country picker data present; customer
stores country; order + receipt carry the merchant's currency (USD); driver
earnings carry the driver's country currency (INR); an AE merchant order
carries AED. Full Jest suite still green (31 tests). Every app file parses.

> No schema change this week.

## Quick start

### 1. Backend
```bash
cd backend
cp .env.example .env        # fill in DATABASE_URL and ANTHROPIC_API_KEY
npm install
npx prisma migrate dev --name init
npm run dev                 # http://localhost:4000/health
```

### 2. Customer app
```bash
cd apps/customer
npm install
npm start                   # open in Expo Go
```

### 3. Driver app
```bash
cd apps/driver
npm install
npm start
```

> On a physical phone, set `API_URL` in each app to your computer's LAN IP
> (e.g. `http://192.168.1.20:4000`), not `localhost`.

## Day 1 checklist

- [ ] Monorepo pushed to Git
- [ ] `apps/customer` runs, blank screen
- [ ] `apps/driver` runs, blank screen
- [ ] Backend runs, `GET /health` returns ok
- [ ] Postgres connected, 7 models migrated
- [ ] Customer app calls `/health`, logs response
- [ ] `POST /ai/ping` returns a real LLM reply
- [ ] Mapbox token saved (Day 3)
- [ ] Stripe test account created (Day 7)
