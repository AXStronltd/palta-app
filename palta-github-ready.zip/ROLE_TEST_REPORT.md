# Palta — Role-by-Role Flow Test Report

Tested by driving the **real Express backend** through each user role's journey.
Database/payments/SMS are mocked (sandbox can't run Postgres/Stripe/SMS), so this
verifies **application logic and flow**, not live infrastructure.

## ✅ CUSTOMER — fully verified
| Flow | Result |
|------|--------|
| Sign up / verify OTP | PASS |
| Browse restaurants & shops | PASS |
| View a merchant menu | PASS |
| Place an order (priced in KES) | PASS |
| See my orders | PASS |
| AI "order by chat" | PASS |
| Rate a delivered order | PASS |
| Parcel: quote + create + track | PASS |

## ✅ MERCHANT (restaurant / shop) — fully verified
| Flow | Result |
|------|--------|
| Merchant sign up | PASS |
| See incoming orders | PASS |
| Accept an order | PASS |
| Mark preparing | PASS |
| Mark ready (→ triggers dispatch) | PASS |
| Add a menu item | PASS |
| Toggle open/closed | PASS |

## ⚠️ DRIVER — core loop verified; one step unverified
| Flow | Result |
|------|--------|
| Driver sign up | PASS |
| Create/update vehicle profile | PASS |
| Go online | PASS (in e2e) |
| Send location | PASS (in e2e) |
| Get dispatched (nearest driver) | PASS |
| Accept the delivery | PASS |
| Pickup → deliver | PASS |
| View earnings | PASS |
| **Upload KYC document** | **UNVERIFIED** — test harness hung on this sub-flow; route code is structurally valid but not confirmed end-to-end. Needs a check against a real database. |

## Bugs found & fixed during flow testing
1. **AI ordering crash** — `ai/ordering/index.js` required the wrong client path; would crash the AI order endpoint. Fixed.
2. **Kenya not a supported country** — orders in KES failed ("Unsupported country: KE"). Added Kenya to the country config. Launch blocker.
3. **JWT missing country** — parcel/order pricing fell back to the wrong currency. Token now carries country.

## What is NOT covered by these tests
- Real database (Postgres) — mocked
- Real payments moving money — mocked (Kenya needs M-Pesa)
- Real SMS OTP delivery — mocked
- The native app talking to a deployed backend — needs deployment + device
- Driver KYC upload against a real DB — unverified (see above)

## Bottom line
Customer and Merchant roles work end-to-end in logic. The Driver delivery loop
(the core of the role) works. The Driver KYC-upload step and all real-infra paths
still need verification against a deployed backend with a real database.
