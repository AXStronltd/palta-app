# Run the Palta apps on your phone

This gets the **real** Palta customer and driver apps running on your own
phone, talking to the backend on your computer. ~15 minutes the first time.

The apps are React Native (Expo) — native mobile apps, not websites. You
view them through **Expo Go**, a free app that runs your code on your phone
by scanning a QR code.

---

## What you need

- A computer (Mac / Windows / Linux) with **Node.js 18+** installed.
- Your **phone** (iPhone or Android) on the **same Wi‑Fi** as the computer.
- **Expo Go** installed on the phone (App Store / Google Play).
- Postgres running (locally or a cloud URL) — for the backend.

---

## Step 1 — Start the backend

The apps are useless without the API running. In one terminal:

```bash
cd backend
cp .env.example .env          # then open .env and set DATABASE_URL
npm install
npx prisma migrate dev --name init   # first time only — creates the tables
npm run seed                  # loads demo restaurants, shops, admin + owner
npm run dev
```

You should see `backend running on :4000`. Leave this terminal open.

Quick check: open `http://localhost:4000/health` in a browser → `{"status":"ok"}`.

### Find your computer's local IP (your phone needs this, not "localhost")
- **Mac:** `ipconfig getifaddr en0`   (e.g. `192.168.1.23`)
- **Windows:** `ipconfig` → look for "IPv4 Address"
- **Linux:** `hostname -I` → first value

Write it down — call it `YOUR_IP`.

---

## Step 2 — Point the apps at your backend

In **both** `apps/customer/src/lib/api.js` and `apps/driver/src/lib/api.js`,
set the API URL to your computer's IP (NOT localhost — the phone can't reach
localhost on your computer):

```js
export const API_URL = "http://YOUR_IP:4000";   // e.g. http://192.168.1.23:4000
```

---

## Step 3 — Start the customer app

In a **second** terminal:

```bash
cd apps/customer
npm install
npx expo start
```

A QR code appears in the terminal.

- **iPhone:** open the **Camera** app, point at the QR code, tap the banner.
- **Android:** open **Expo Go**, tap "Scan QR code", scan it.

The Palta customer app loads on your phone. Log in with any phone number
(the OTP code prints in the backend terminal and — in dev — auto-fills),
pick a country, and you're in: browse restaurants and shops, order by AI
chat or by tapping, checkout, and track the order live.

---

## Step 4 — Start the driver app (optional, second device is best)

In a **third** terminal:

```bash
cd apps/driver
npm install
npx expo start
```

Scan with a second phone (or the same one — stop the customer app first).
Log in as a driver, complete KYC, go online. To approve the driver, open the
admin console (`admin/index.html`) and approve them, or set
`AUTO_APPROVE_KYC=1` in the backend `.env`.

Now: order on the customer phone → the restaurant readies it (restaurant
dashboard, or admin) → the driver phone gets the request → accept and
deliver → watch it move on the customer's live map.

---

## Common snags (honest heads-up)

- **App loads but everything errors / "network error":** the `API_URL` is
  wrong or still `localhost`. It must be `http://YOUR_IP:4000`, and phone +
  computer must be on the same Wi‑Fi.
- **QR won't connect:** some networks block device‑to‑device. Try
  `npx expo start --tunnel` (slower but works across networks).
- **Backend won't start — Prisma error:** you skipped `npx prisma migrate
  dev`. Run it once; it creates the database tables.
- **No restaurants show:** you skipped `npm run seed`.
- **Maps are blank / OTP not sending:** those need `MAPBOX_TOKEN` and an SMS
  provider. In dev the OTP is printed in the backend terminal, so you don't
  need SMS to log in. Maps fall back to a "needs token" placeholder.
- **"This won't run in Expo Go" for the live map:** the app uses static map
  images by default so it DOES run in Expo Go. The smooth native map is an
  optional upgrade needing a custom build (see LiveMap.native-notes.md).

---

## Reality check

This is the genuine app running on a real device against a real server —
the true test of everything built so far. Until you've done this, the app
has only ever run against mocked pieces in a sandbox. Expect small
first-run issues (a wrong IP, a missing env var); that's normal, not a sign
something's broken. Work through the snags above and it comes up.
