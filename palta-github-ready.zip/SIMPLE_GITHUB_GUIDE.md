# Put Palta on GitHub — Simple Guide (No Coding Needed)

You don't need to be a developer. Just follow these steps in order.
GitHub is like Google Drive, but for code — a safe place that stores your
project and lets you deploy it later.

There are TWO ways. Pick the one that feels easier for you.

═══════════════════════════════════════════════════════════
  WAY 1 — The EASY way: upload in the browser (recommended for you)
═══════════════════════════════════════════════════════════

No installing anything. All done in your web browser.

### Step 1 — Make a GitHub account (if you don't have one)
- Go to  https://github.com/signup
- Sign up with your email. It's free.

### Step 2 — Create an empty project ("repository")
- Go to  https://github.com/new
- **Repository name:** type  `palta`
- Choose **Private** (only you can see it)
- Do NOT tick "Add a README file" (your project already has one)
- Click the green **Create repository** button

### Step 3 — Get your Palta files ready
- Download the file I gave you:  **palta-github-ready.zip**
- **Unzip it** (double-click it on Mac, or right-click → Extract on Windows)
- You now have a folder called `palta` with all your files inside

### Step 4 — Upload the files
- On your new empty GitHub page, look for a link that says
  **"uploading an existing file"** (it's in the middle of the page)
- Click it
- Open your unzipped `palta` folder on your computer
- Select ALL the files and folders inside it, and **drag them** onto the
  GitHub upload area
  - (If drag-drop is fussy, click "choose your files" and select them)
- Wait for them to finish uploading (a minute or two)
- Scroll down, click the green **Commit changes** button

✅ DONE. Your code is now safely on GitHub. Refresh the page and you'll see
all your folders (apps, backend, restaurant, etc.).

═══════════════════════════════════════════════════════════
  WAY 2 — Using GitHub Desktop (a free app, also no coding)
═══════════════════════════════════════════════════════════

If you'd rather use an app than drag files in a browser:

1. Download **GitHub Desktop**:  https://desktop.github.com  (free)
2. Install and sign in with your GitHub account.
3. Click **File → Add Local Repository**, and pick your unzipped `palta` folder.
   - If it says "this isn't a git repository," click **"create a repository"** —
     that's fine, let it.
4. On the left, you'll see all your files listed. At the bottom-left, type a
   short message like "First upload" in the Summary box, then click the blue
   **Commit to main** button.
5. Click **Publish repository** at the top. Choose **Private**. Click Publish.

✅ DONE. Same result — your code is on GitHub.

═══════════════════════════════════════════════════════════
  WHAT NOT TO WORRY ABOUT
═══════════════════════════════════════════════════════════

- You will NOT accidentally share passwords or keys. The project has a
  `.gitignore` file that automatically hides sensitive files. I checked —
  it's clean.
- "Private" means only you can see it. You can invite a developer later.
- If an upload fails halfway, just try again — it won't break anything.

═══════════════════════════════════════════════════════════
  WHEN YOU'VE DONE THIS
═══════════════════════════════════════════════════════════

Tell me "it's on GitHub" and send me nothing else — I'll guide you to the
NEXT step: deploying the backend so it's actually live on the internet
(that's the `DEPLOY_TO_GITHUB.md` Part 2, and I'll walk you through it the
same simple way).

One step at a time. You've got this.
