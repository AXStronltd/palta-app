# Palta — Gap Analysis & Roadmap
### Vision vs. Built vs. Missing — for developers & investors

**Prepared from the actual Palta codebase** (backend routes, Prisma schema,
services, providers), not from assumptions. Where something is marked "Built,"
it exists in code and passes unit tests against mocked infrastructure. Where a
feature depends on real infrastructure (payments, live GPS, deployment), that
is called out explicitly.

---

## 1. Executive summary

Palta today is **a well-architected backend for a multi-role local-commerce
and delivery marketplace, plus a high-fidelity customer-app prototype.** The
foundations the vision calls for — four roles, multiple merchant types, a
rule-based dispatch engine, an order state machine, a global country layer —
are already in place as code.

The distance to a launchable product is not primarily *architecture*; it is
**real infrastructure and three specific feature gaps**:

1. **Nothing has run against real infrastructure yet** — no deployed backend,
   no database migration applied, no real payment vendor, no real device GPS.
   All current tests use mocked Prisma / Stripe / SMS / maps.
2. **Parcel delivery does not exist** — and per your own correction, the order
   model must treat food, shop, and parcel as one "delivery job" *now* to
   avoid a costly rewrite. (Detailed below — this is the single most important
   architectural change.)
3. **Multi-role identity is not implemented** — a user has exactly one role
   today, not the customer+merchant+driver identity the vision requires.

Everything else is either built, or is a matter of completing/hardening
existing code rather than starting from zero.

---

## 2. The one architectural correction (do this first)

> **"Don't treat parcel delivery as a later add-on. Build the dispatch/order
> architecture so food, shop orders, and parcels are all delivery jobs."**

This is correct and urgent. Here is the concrete state:

- **Today:** the `Order` model is merchant-centric. It has `deliveryType`
  (only `DELIVERY` | `PICKUP`) and always references a `Restaurant`. There is
  no concept of a job with a free-form pickup + drop-off and no merchant.
- **Required:** introduce a **`Job` / delivery-job abstraction** where a
  food order, a shop order, and a parcel are all *types of the same job*:
  - `jobType: FOOD | SHOP | PARCEL`
  - pickup location + drop-off location as first-class fields (a merchant
    order fills pickup from the merchant; a parcel fills it from the sender)
  - the **dispatch engine keys off the job's pickup point**, not off a
    restaurant — so it already works for parcels the day you add them.

Doing this refactor **before** launch means parcels, and any future delivery
type (packages, pharmacy scripts, returns), are configuration — not a rewrite.
This is a P0 architectural task even though the parcel *UI* can come later.

---

## 3. Vision vs. Built vs. Missing — by priority area

### 3.1 Core marketplace (customers, restaurants, shops, drivers)

| Capability | Vision | Built | Missing |
|---|---|---|---|
| Customer accounts (phone/OTP) | ✓ | ✓ Built | Real SMS vendor for OTP |
| Browse / search merchants | ✓ | ✓ Built | — |
| Cart, checkout, server-side pricing | ✓ | ✓ Built | — |
| Restaurants as merchants | ✓ | ✓ Built | — |
| Shops/retailers (grocery, pharmacy, retail) | ✓ | ✓ Built (`MerchantType` enum; one marketplace, not a separate app) | Convenience/electronics/clothing are data, not code — fine |
| Drivers | ✓ | ✓ Built (KYC, online/offline, delivery actions, earnings) | Real KYC vendor, live GPS |
| Ratings / reviews | ✓ | ✓ Built | — |
| Order history / receipts / reorder | ✓ | ✓ Built | — |
| Refund / support | ✓ | ✗ | **Missing** — no refund or support tooling |

**Assessment:** the core marketplace is the most complete area. The "not a
separate shop app" principle is already how it's built.

### 3.2 Packages / parcel delivery

| Capability | Vision | Built | Missing |
|---|---|---|---|
| Sender creates delivery | ✓ | ✗ | **Missing** |
| Pickup + drop-off addresses as job fields | ✓ | ✗ | **Missing** (see §2) |
| Package type / size | ✓ | ✗ | **Missing** |
| Driver dispatch for parcels | ✓ | ◑ Partial — engine exists but keys off a restaurant | Re-key dispatch to job pickup |
| Live tracking | ✓ | ◑ Reusable from orders | Wire to parcel jobs |
| Proof of delivery (photo/signature/PIN) | ✓ | ✗ | **Missing** |
| Parcel pricing (distance/size) | ✓ | ◑ Surge/distance concept exists | Parcel-specific pricing |

**Assessment:** not built. But most of it *reuses* dispatch, tracking, and
earnings once the job abstraction (§2) exists.

### 3.3 True multi-role identity

| Capability | Vision | Built | Missing |
|---|---|---|---|
| One Palta account | ✓ | ✓ Built | — |
| Customer + merchant + driver on one identity | ✓ | ✗ Single `role` per user | **Missing** |
| Easy role switching | ✓ | ✗ | **Missing** |
| Separate dashboards / permissions per role | ✓ | ◑ Dashboards exist, gated by single role | Refactor auth to role *set* |

**Assessment:** today `User.role` is one of CUSTOMER/DRIVER/ADMIN/RESTAURANT.
The vision's "Ahmed is all three" needs a **roles array** (or a join table)
plus a role-switch in the app and permission checks per active role. Medium
refactor, high network-effect payoff.

### 3.4 Real payment infrastructure

| Capability | Vision | Built | Missing |
|---|---|---|---|
| Payment abstraction (country-pluggable) | ✓ | ✓ Built (interface + Stripe adapter + regional stubs) | — |
| Customer payment (real money) | ✓ | ✗ Mock mode only | **Missing** — wire one real vendor |
| Merchant settlement | ✓ | ✗ | **Missing** |
| Driver earnings recorded | ✓ | ✓ Built (earnings ledger) | Real payout rail |
| Driver payouts (real money out) | ✓ | ✗ | **Missing** |
| Palta commission | ✓ | ◑ Pricing exists | Commission split not implemented |
| Refunds | ✓ | ✗ | **Missing** |
| Failed payments / retries | ✓ | ✗ | **Missing** |
| Reconciliation / settlement ledger | ✓ | ✗ | **Missing** |

**Assessment:** the *abstraction* is built and clean; the *money* is entirely
mocked. This is the biggest business-critical gap. Until one real vendor is
wired end-to-end for one country, Palta cannot transact.

### 3.5 Dispatch engine

| Capability | Vision | Built | Missing |
|---|---|---|---|
| Driver matching | ✓ | ✓ Built (nearest online, approved, free) | — |
| Distance / ETA | ✓ | ◑ Distance (haversine) built; ETA not | ETA calc |
| Availability (online/offline) | ✓ | ✓ Built | — |
| Merchant preparation time | ✓ | ◑ Prep time stored | Not yet a dispatch input |
| Vehicle type / capacity | ✓ | ✗ | **Missing** as a matching factor |
| Driver workload | ✓ | ◑ "not already on an order" | Multi-order batching missing |
| Automatic reassignment (declined/timeout) | ✓ | ✓ Built (30s offer, next driver) | — |
| Delivery status lifecycle | ✓ | ✓ Built (state machine, guarded) | — |

**Assessment:** genuinely one of the stronger areas — a working rule-based
engine with reassignment. Enrichments (ETA, vehicle, prep-time weighting,
batching) are P1/P2, not blockers.

### 3.6 Merchant infrastructure

| Capability | Vision | Built | Missing |
|---|---|---|---|
| Restaurant onboarding + KYC | ✓ | ✓ Built (self-signup, needs-setup flow) | Real business KYC vendor |
| Shop onboarding (same pipeline) | ✓ | ✓ Built (merchant type) | — |
| Products / menu + options + photos | ✓ | ✓ Built | Image hosting at scale |
| Inventory / availability | ✓ | ◑ `isAvailable` per item | True stock counts missing |
| Opening hours | ✓ | ◑ `isOpen` toggle | Scheduled hours missing |
| Receive / accept / reject orders | ✓ | ✓ Built (realtime) | — |
| Earnings | ✓ | ✓ Built | Payout rail (see payments) |

### 3.7 Driver infrastructure

| Capability | Vision | Built | Missing |
|---|---|---|---|
| KYC | ✓ | ✓ Built (docs, statuses, admin review) | Real KYC vendor |
| Vehicle verification | ✓ | ◑ Vehicle fields + docs | Verification workflow |
| Online / offline | ✓ | ✓ Built | — |
| Delivery requests (accept/decline) | ✓ | ✓ Built | — |
| Navigation | ✓ | ✗ Static maps | **Missing** — turn-by-turn |
| Earnings dashboard | ✓ | ✓ Built | — |
| Payouts | ✓ | ✗ | **Missing** (see payments) |

### 3.8 Admin / control centre

| Capability | Vision | Built | Missing |
|---|---|---|---|
| Users | ✓ | ◑ Via drivers/orders views | Full user admin |
| Merchants | ✓ | ◑ | Dedicated merchant admin |
| Drivers (review/approve KYC) | ✓ | ✓ Built | — |
| Orders | ✓ | ✓ Built (list, status override) | — |
| Deliveries | ✓ | ◑ Same as orders today | Split once jobs exist |
| Payments | ✓ | ✗ | **Missing** |
| Disputes | ✓ | ✗ | **Missing** |
| Commissions | ✓ | ✗ | **Missing** |
| Analytics | ✓ | ◑ Basic stats endpoint | Real dashboards |
| Fraud / risk | ✓ | ✗ | **Missing** |

### 3.9 Launch-country requirements

| Requirement | Built | Missing |
|---|---|---|
| Payments (one country) | ✗ mock | **Integrate real vendor** |
| Maps / location | ◑ static Mapbox | Live maps + navigation |
| SMS / notifications | ◑ push built; SMS stub | Real SMS vendor |
| KYC | ◑ interface | Real KYC vendor |
| Merchant/driver verification | ◑ manual admin | Automated checks |
| Tax / receipts | ◑ receipts built | Tax rules per country |
| Local delivery rules | ✗ | Per-country config |

---

## 4. Priority roadmap

### P0 — Must have before launch
- **Refactor Order → Job abstraction** (food/shop/parcel as one job; pickup +
  drop-off as first-class). *Do this before adding parcel UI.* (§2)
- **Wire ONE real payment vendor end-to-end** for one launch country:
  customer charge → Palta commission split → merchant settlement → driver
  earnings. Plus failed-payment handling.
- **Complete dispatch for jobs** (key off pickup, not restaurant).
- **Deploy the backend for real** (DB migration applied, backend on
  Fly/Render, Redis) — nothing is real until this happens.
- **Real SMS** for OTP, **real KYC** for drivers/merchants (launch country).
- **Multi-role identity** (roles array + role switch) — or consciously defer
  to P1 if launching single-role first.
- **Refunds** (at least basic) and **proof of delivery**.

### P1 — Launch enhancement
- Parcel delivery UI (sender flow) on top of the P0 job engine.
- Live GPS + navigation for drivers.
- ETA calculation; prep-time and vehicle type as dispatch inputs.
- Merchant scheduled opening hours; real inventory counts.
- Admin: payments view, disputes, commissions.

### P2 — Scale features
- Multi-order batching / driver workload optimisation.
- Analytics dashboards; fraud/risk rules.
- Promotions/vouchers engine; loyalty (Palta One).
- Multi-country expansion using the existing country layer.

### P3 — Future Palta super-app
- Packages across further categories, returns, scheduled deliveries.
- Rides (the vision hints at it), bill pay, wallet.
- Merchant lending/float against settlement; driver instant payout.
- Open API / partner marketplace.

---

## 5. Master feature table

| Feature | Vision | Already Built | Missing | Priority | Developer Action |
|---|---|---|---|---|---|
| Food ordering | Yes | Yes | — | P0 | Harden |
| Shops/retail | Yes | Yes | — | P0 | Harden |
| Drivers | Yes | Yes | Real GPS/KYC | P0 | Complete |
| Customer accounts | Yes | Yes | Real SMS | P0 | Integrate SMS |
| Order → Job abstraction | Yes | No | Whole refactor | P0 | **Build first** |
| Parcel delivery | Yes | No | Sender flow, PoD, pricing | P0 arch / P1 UI | Build on job engine |
| Multi-role identity | Yes | No | Roles array, switch, perms | P0/P1 | Build |
| Payments (real) | Yes | Abstraction only | Vendor, splits, refunds, recon | P0 | Integrate 1 vendor |
| Merchant settlement | Yes | No | Payout + commission split | P0 | Build |
| Driver payouts | Yes | Earnings only | Real payout rail | P0 | Build |
| Dispatch engine | Yes | Yes (rule-based) | ETA, vehicle, prep, batching | P0 core / P1 rest | Complete |
| Merchant onboarding | Yes | Yes | Real KYC | P0 | Integrate KYC |
| Menu/products | Yes | Yes | Scaled image hosting | P0 | Harden |
| Inventory/hours | Yes | Partial | Stock counts, scheduled hours | P1 | Extend |
| Driver KYC/vehicle | Yes | Yes | Real vendor, verification flow | P0 | Integrate |
| Navigation | Yes | No | Turn-by-turn | P1 | Build |
| Refunds | Yes | No | Refund flow | P0 | Build |
| Proof of delivery | Yes | No | Photo/PIN/signature | P0 | Build |
| Admin: drivers/orders | Yes | Yes | — | P0 | — |
| Admin: payments/disputes | Yes | No | Full tooling | P1 | Build |
| Analytics | Yes | Basic | Dashboards | P2 | Build |
| Fraud/risk | Yes | No | Rules engine | P2 | Build |
| Live GPS tracking | Yes | Demo only | Real device streaming | P1 | Wire |
| Chat/call driver↔customer | Yes | No | Messaging/voice | P1 | Build |
| Deployment (live) | Yes | No | DB migrate + host | P0 | Deploy |

---

## 6. Honest closing note

The value already in Palta is real: a coherent, multi-role marketplace backend
with a working dispatch engine, a global country/currency layer, and a strong
customer-app design. The gaps are equally real and mostly infrastructural.
**The fastest credible path to launch is a tightly scoped P0: one country, one
payment vendor, the job-abstraction refactor, real deployment, and either
single-role at launch or the multi-role refactor if time allows.** Parcels then
fall out almost for free because the architecture was built to treat every
delivery — food, shop, or package — as the same kind of job.

*All "Built" claims reflect code tested against mocked infrastructure; first
real integration will surface normal integration issues. This is expected for a
pre-launch platform.*
