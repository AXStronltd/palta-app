// ============================================================
// Palta shared types & constants
// Single source of truth for both apps + backend.
// ============================================================

// ---- Enums ----

export const UserRole = {
  CUSTOMER: "CUSTOMER",
  DRIVER: "DRIVER",
} as const;
export type UserRole = (typeof UserRole)[keyof typeof UserRole];

export const DeliveryType = {
  DELIVERY: "DELIVERY",
  PICKUP: "PICKUP",
} as const;
export type DeliveryType = (typeof DeliveryType)[keyof typeof DeliveryType];

export const KycStatus = {
  PENDING: "PENDING",
  APPROVED: "APPROVED",
  REJECTED: "REJECTED",
} as const;
export type KycStatus = (typeof KycStatus)[keyof typeof KycStatus];

// ---- The order status state machine ----
// PLACED → ACCEPTED → PREPARING → READY →
// DRIVER_ASSIGNED → PICKED_UP → DELIVERING → DELIVERED
// exits: CANCELLED, REJECTED
export const OrderStatus = {
  PLACED: "PLACED",
  ACCEPTED: "ACCEPTED",
  PREPARING: "PREPARING",
  READY: "READY",
  DRIVER_ASSIGNED: "DRIVER_ASSIGNED",
  PICKED_UP: "PICKED_UP",
  DELIVERING: "DELIVERING",
  DELIVERED: "DELIVERED",
  CANCELLED: "CANCELLED",
  REJECTED: "REJECTED",
} as const;
export type OrderStatus = (typeof OrderStatus)[keyof typeof OrderStatus];

// Allowed forward transitions. The backend validates every status
// change against this — nothing may jump or invent a state.
export const ORDER_TRANSITIONS: Record<OrderStatus, OrderStatus[]> = {
  PLACED: ["ACCEPTED", "REJECTED", "CANCELLED"],
  ACCEPTED: ["PREPARING", "CANCELLED"],
  PREPARING: ["READY", "CANCELLED"],
  READY: ["DRIVER_ASSIGNED", "CANCELLED"],
  DRIVER_ASSIGNED: ["PICKED_UP", "CANCELLED"],
  PICKED_UP: ["DELIVERING", "CANCELLED"],
  DELIVERING: ["DELIVERED", "CANCELLED"],
  DELIVERED: [],
  CANCELLED: [],
  REJECTED: [],
};

// ---- Core entity types (mirror the Prisma schema) ----

export interface User {
  id: string;
  phone: string;
  email?: string | null;
  name?: string | null;
  role: UserRole;
  createdAt: string;
}

export interface Address {
  id: string;
  userId: string;
  label: string;
  lat: number;
  lng: number;
  fullAddress: string;
  notes?: string | null;
}

export interface Restaurant {
  id: string;
  name: string;
  description?: string | null;
  imageUrl?: string | null;
  lat: number;
  lng: number;
  address: string;
  cuisineType: string;
  rating: number;
  deliveryFee: number;
  estimatedPrepTime: number; // minutes
  isOpen: boolean;
}

export interface MenuItem {
  id: string;
  restaurantId: string;
  name: string;
  description?: string | null;
  price: number;
  imageUrl?: string | null;
  category: string;
  isAvailable: boolean;
}

export interface OrderItem {
  menuItemId: string;
  name: string;
  price: number;
  quantity: number;
  notes?: string;
}

export interface Order {
  id: string;
  customerId: string;
  restaurantId: string;
  driverId?: string | null;
  status: OrderStatus;
  items: OrderItem[];
  subtotal: number;
  deliveryFee: number;
  tip: number;
  total: number;
  deliveryAddress: string;
  deliveryType: DeliveryType;
  createdAt: string;
}

export interface DriverProfile {
  id: string;
  userId: string;
  vehicleType: string;
  licensePlate: string;
  kycStatus: KycStatus;
  isOnline: boolean;
  currentLat?: number | null;
  currentLng?: number | null;
}

export interface ConversationSession {
  id: string;
  customerId: string;
  messages: { role: "user" | "assistant"; content: string }[];
  resolvedCart?: OrderItem[] | null;
  status: string;
}
