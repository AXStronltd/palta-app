# 👋 START HERE — Palta

This is the complete Palta platform, ready to put on GitHub and deploy.

## What's inside (everything is built and checked)

**Customer app** (`apps/customer`) — 18 screens
- Login (phone + OTP), Home, Restaurants, Restaurant menu, **Store (grocery
  catalog)**, Item detail, Checkout, Order placed, **Live order tracking**,
  Orders list, **Parcel create + live parcel tracking**, Rate order, Receipt,
  Addresses, **Profile**, Role select

**Driver app** (`apps/driver`) — 5 screens
- Login, KYC, Driver home (go online, see jobs), **Incoming-order alarm
  (vibration + sound + countdown)**, **Active delivery navigation**

**Merchant dashboard** (`restaurant/index.html`)
- Live orders, accept/reject/prepare/ready, **add/edit/stock-toggle/delete
  products**, live status refresh

**Backend** (`backend`) — 13 API routes, 8 services
- Auth, orders, drivers, restaurants, parcels, addresses, AI, geo, admin,
  ops, config, health + the **order state machine**, **dispatch**,
  **payment adapters** (M-Pesa / card / EVC, with mock mode), realtime
  (Socket.IO), push

**Deployment ready**
- `render.yaml` — one-click deploy (backend + Postgres + Redis)
- `backend/Dockerfile` — production image
- Database migration — creates all tables on deploy
- GitHub Actions CI — runs tests on every push

## Status (honest)
- ✅ All code written and syntax-checked (0 errors)
- ✅ Payments in **mock/cash mode** — works now, real M-Pesa plugs in later
  with just env keys (see `PAYMENTS_STRATEGY.md`)
- ⏳ Not yet deployed (that's your next step — 10 min)
- ⏳ Real payments, SMS, KYC, store submission — when you have those accounts
- ⏳ Drivers & shops recruited — the actual launch (business work)

## Your next steps (simple guides included)
1. **`SIMPLE_GITHUB_GUIDE.md`** — put this on GitHub (you're doing this now)
2. **`DEPLOY_TO_GITHUB.md`** — make the backend live (next)
3. **`NEXT_STEPS.md`** — the full path to launch, step by step
4. **`PAYMENTS_STRATEGY.md`** — how payments plug in later

You have a real, well-built platform here. One step at a time.
